#include "parity_array.h"
#include <stdio.h>
#include <stdlib.h>

void init(struct ParityArray *parityArray, int size) {
    parityArray->array = malloc(size * sizeof(int));
    parityArray->even_idx = 0;
    parityArray->odd_idx = size - 1;
}

void insert(struct ParityArray *parityArray, int num) {
    if (num % 2 == 0) {
        parityArray->array[parityArray->even_idx++] = num;
    } else {
        parityArray->array[parityArray->odd_idx--] = num;
    }
}

void print(struct ParityArray *parityArray) {
    int i;
	for ( i = 0; i < parityArray->even_idx; i++) {
        printf("%d ", parityArray->array[i]);
    }
    for ( i = parityArray->odd_idx + 1; i < ARRAY_SIZE; i++) {
        printf("%d ", parityArray->array[i]);
    }
}

void destruct(struct ParityArray *parityArray) {
    free(parityArray->array);
}

void dump(struct ParityArray *parityArray, char *filename) {
    FILE *fp = fopen(filename, "w");
    if (fp == NULL) {
        perror("Error opening file");
        return;
    }

    for (int i = 0; i < parityArray->even_idx; i++) {
        fprintf(fp, "%d ", parityArray->array[i]);
    }
    for (int i = parityArray->odd_idx + 1; i < ARRAY_SIZE; i++) {
        fprintf(fp, "%d ", parityArray->array[i]);
    }

    fclose(fp);
}


