#include "parity_array.h"
#include <stdio.h>

int main() {
    int size;
    //printf("Enter size of array: ");
    scanf("%d", &size);

    struct ParityArray parityArray;
    init(&parityArray, size);

    int num;
    //printf("Enter numbers to insert into array: ");
    while (scanf("%d", &num) == 1) {
        insert(&parityArray, num);
    }

    //printf("Parity array: ");
    print(&parityArray);
    printf("\n");

    dump(&parityArray, "parity_array.txt");

    destruct(&parityArray);

    return 0;
}

