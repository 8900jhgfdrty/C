#ifndef PARITY_ARRAY_H
#define PARITY_ARRAY_H

#define ARRAY_SIZE 10

struct ParityArray {
    int *array;
    int even_idx;
    int odd_idx;
};

void init(struct ParityArray *parityArray, int size);
void insert(struct ParityArray *parityArray, int num);
void print(struct ParityArray *parityArray);
void destruct(struct ParityArray *parityArray);
void dump(struct ParityArray *parityArray, char *filename);
#endif

